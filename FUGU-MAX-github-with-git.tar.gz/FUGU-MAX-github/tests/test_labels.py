#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""اختبارات التسميات: لا تطلّع، وشكل النتائج، وسياسة SL-أولًا."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import numpy as np
import pandas as pd
import pytest
from config import Config
from data import make_synthetic_data
from labels import compute_labels, label_report, _first_barrier_hit


@pytest.fixture(scope="module")
def data():
    cfg = Config()
    return cfg, make_synthetic_data(1500, seed=5)


def test_label_shapes_and_ranges(data):
    cfg, df = data
    lab = compute_labels(df, cfg)
    assert list(lab.columns) == ["fwd_ret", "y_barrier", "r_mult", "bars_to_exit", "meta"]
    r = lab["r_mult"].dropna()
    assert r.min() > -1.5 and r.max() < (cfg.atr_tp_mult / cfg.atr_stop_mult) + 1.0


def test_no_lookahead_labels(data):
    cfg, df = data
    cut = 900
    full = compute_labels(df, cfg).iloc[:cut - 40]
    part = compute_labels(df.iloc[:cut], cfg).iloc[:cut - 40]
    d = (full.fillna(-7) - part.fillna(-7)).abs().max().max()
    assert d < 1e-9, f"تسرّب مستقبلي في التسميات: {d}"


def test_sl_first_on_ambiguous_bar():
    """شمعة تضرب الحاجزين: يجب أن تُحسب SL أولًا (سياسة محافظة)."""
    o = np.array([100, 100]); h = np.array([101, 120]); l = np.array([99, 80]); c = np.array([100, 110])
    res, px, nb = _first_barrier_hit(h, l, 100.0, 95.0, 115.0, o, h, l, c, 1, 5)
    assert res == -1.0 and px == 95.0


def test_meta_uses_costs(data):
    cfg, df = data
    lab = compute_labels(df, cfg)
    rep = label_report(lab)
    assert 0.0 <= rep["meta_positive_share"] <= 1.0
    assert rep["n"] > 500
