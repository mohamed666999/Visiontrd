#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""اختبارات الاختبار الخلفي: تنفيذ عند الفتح، بلا تطلّع، اتّساق المحاسبة."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import numpy as np
import pandas as pd
import pytest
from config import Config
from data import make_synthetic_data
from backtest import run, metrics, walk_forward


@pytest.fixture(scope="module")
def small():
    cfg = Config()
    return cfg, make_synthetic_data(1200, seed=21)


def test_backtest_runs(small):
    cfg, df = small
    r = run(df, cfg, mode="adaptive", warmup=500)
    assert len(r["equity"]) == len(df)
    assert np.isfinite(r["equity"].iloc[-1])


def test_entry_at_next_open(small):
    """كل مركز يجب أن يكون سعر دخوله مساويًا لفتح شمعة فعلية."""
    cfg, df = small
    r = run(df, cfg, mode="no_meta", warmup=400, learn=False)
    tr = r["trades"]
    if len(tr):
        opens = set(np.round(df["open"].values, 8))
        for _, row in tr.iterrows():
            assert round(float(row["entry"]), 8) in opens


def test_sl_first_policy(small):
    cfg, df = small
    r = run(df, cfg, mode="fixed", warmup=400, learn=False)
    tr = r["trades"]
    if len(tr):
        for _, row in tr[tr["reason"] == "SL"].iterrows():
            if row["side"] > 0:
                assert row["exit"] <= row["entry"]
            else:
                assert row["exit"] >= row["entry"]


def test_positive_equity(small):
    """رأس المال لا يصبح سالبًا ولا NaN في أي نمط."""
    cfg, df = small
    for mode in ("adaptive", "fixed", "random", "buy_hold"):
        eq = run(df, cfg, mode=mode, warmup=400)["equity"]
        assert (eq > 0).all(), f"{mode}: رأس مال غير صالح"
        assert np.isfinite(eq).all()


def test_metrics_keys(small):
    cfg, df = small
    r = run(df, cfg, mode="no_meta", warmup=400)
    m = metrics(r["equity"], cfg, len(r["trades"]))
    for k in ("total_return", "sharpe", "max_drawdown", "calmar", "n_trades"):
        assert k in m


def test_frozen_engine_does_not_learn():
    """حالة التعلّم يجب ألا تتغير إطلاقًا عند learn=False."""
    cfg = Config()
    df = make_synthetic_data(1000, seed=9)
    eng = run(df, cfg, mode="adaptive", warmup=400, learn=True)["engine"]
    before = {
        "steps": eng.steps,
        "stats": {k: (v.weight, v.wins, v.n, v.cum_r) for k, v in eng.stats.items()},
        "regime_w": eng.regime_w.copy(),
        "logistic_w": eng.logistic.w.copy(), "logistic_b": eng.logistic.b,
        "rls_w": eng.rls.w.copy(), "rls_b": eng.rls.b, "rls_P": eng.rls.P.copy(),
    }
    run(make_synthetic_data(300, seed=99), cfg, mode="adaptive",
        warmup=100, learn=False, engine=eng)
    assert eng.steps == before["steps"], "خطوات التعلّم زادت رغم التجميد"
    assert {k: (v.weight, v.wins, v.n, v.cum_r) for k, v in eng.stats.items()} == before["stats"]
    np.testing.assert_allclose(eng.regime_w, before["regime_w"], atol=1e-12)
    np.testing.assert_allclose(eng.logistic.w, before["logistic_w"], atol=1e-12)
    assert eng.logistic.b == before["logistic_b"]
    np.testing.assert_allclose(eng.rls.w, before["rls_w"], atol=1e-12)
    assert eng.rls.b == before["rls_b"]
    np.testing.assert_allclose(eng.rls.P, before["rls_P"], atol=1e-12)


def test_walk_forward_shapes():
    cfg = Config()
    df = make_synthetic_data(2500, seed=3)
    wf = walk_forward(df, cfg, n_splits=2, mode="fixed", verbose=False)
    assert len(wf) == 2
    assert wf["max_drawdown"].max() < 1.0
