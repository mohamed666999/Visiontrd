#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""اختبارات الميزات: سببية (No look-ahead) + حدود القيم."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import numpy as np
import pandas as pd
import pytest
from config import Config
from data import make_synthetic_data
from features import build_features, build_expert_inputs, FEATURE_GROUPS


@pytest.fixture(scope="module")
def data():
    cfg = Config()
    return cfg, make_synthetic_data(1500, seed=11)


def test_feature_count(data):
    cfg, df = data
    f = build_features(df, cfg)
    assert f.shape[0] == len(df)
    assert f.shape[1] >= 30


def test_no_lookahead_prefix_invariance(data):
    """الميزة عند t يجب ألا تتغير عند إضافة شمعات مستقبلية."""
    cfg, df = data
    cut = 900
    f_full = build_features(df, cfg)
    f_cut = build_features(df.iloc[:cut], cfg)
    common = [c for c in f_full.columns if c in f_cut.columns]
    a = f_full[common].iloc[:cut - 60]
    b = f_cut[common].iloc[:cut - 60]
    diff = (a.fillna(-999) - b.fillna(-999)).abs().max().max()
    assert diff < 1e-6, f"تسرّب مستقبلي: أقصى فرق {diff}"


def test_expert_inputs_bounds(data):
    cfg, df = data
    e = build_expert_inputs(build_features(df, cfg))
    v = e.dropna()
    assert v.abs().max().max() <= 1.0 + 1e-9
    assert "dir_momentum" in v.columns and "dir_reversion" in v.columns


def test_groups_known():
    for name, cols in FEATURE_GROUPS.items():
        assert len(cols) > 0
