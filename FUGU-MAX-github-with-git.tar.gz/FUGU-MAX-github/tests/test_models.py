#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""اختبارات المحرّك: أوزان، حدود، تعلّم فعلي، انجراف، أنظمة."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import numpy as np
import pytest
from config import Config
from models import (Ensemble, DriftMonitor, RegimeDetector, RLSExpert,
                    LogisticExpert, EXPERT_NAMES)


def test_rls_learns_linear():
    n = 5
    rls = RLSExpert(n, lam=0.999, delta=100.0)
    rng = np.random.default_rng(0)
    w_true = np.array([0.5, -0.3, 0.2, 0.0, 0.8])
    for _ in range(600):
        x = rng.standard_normal(n)
        y = float(w_true @ x)
        rls.update(x, y)
    x = rng.standard_normal(n)
    err = abs(rls.predict(x) - float(w_true @ x))
    assert err < 0.25, f"RLS لم يتعلّم: {err}"


def test_logistic_learns_separation():
    n = 4
    lg = LogisticExpert(n, lr=0.1)
    rng = np.random.default_rng(1)
    w = np.array([1.2, -0.8, 0.5, 0.3])
    for _ in range(1500):
        x = rng.standard_normal(n)
        y = 1.0 if float(w @ x) > 0 else 0.0
        lg.update(x, y)
    acc = np.mean([lg.proba(rng.standard_normal(n) * 0) >= 0 for _ in range(1)])
    xs = rng.standard_normal((300, n))
    pred = np.array([1.0 if lg.proba(x) > 0.5 else 0.0 for x in xs])
    true = (xs @ w > 0).astype(float)
    assert (pred == true).mean() > 0.85


def test_ensemble_weights_normalized():
    cfg = Config()
    e = Ensemble(cfg, 37)
    e.attach_drift(DriftMonitor())
    x = np.zeros(37); d = {f"dir_{k}": 0.5 for k in
                           ["momentum", "trend", "reversion", "flow", "volatility"]}
    e.score(x, d, 0)
    w = e.weights()
    assert abs(w.sum() - 1.0) < 1e-9
    assert len(w) == len(EXPERT_NAMES)


def test_ensemble_learns_weights():
    """يجب أن يرتفع وزن الخبير الذي يصيب باستمرار."""
    cfg = Config()
    e = Ensemble(cfg, 37)
    e.attach_drift(DriftMonitor())
    x = np.zeros(37)
    d = {f"dir_{k}": 0.0 for k in ["momentum", "trend", "reversion", "flow", "volatility"]}
    d["dir_momentum"] = 1.0
    w0 = e.weights()[EXPERT_NAMES.index("momentum")]
    for _ in range(400):
        e.learn(x, d, realized_ret=+0.01, regime=0, y_barrier=1.0, meta_target=1.0)
    w1 = e.weights()[EXPERT_NAMES.index("momentum")]
    assert w1 > w0, f"الوزن لم يتغيّر ({w0} → {w1})"


def test_score_bounds():
    cfg = Config()
    e = Ensemble(cfg, 20)
    e.attach_drift(DriftMonitor())
    rng = np.random.default_rng(3)
    for _ in range(500):
        x = rng.standard_normal(20) * 5
        d = {f"dir_{k}": float(rng.uniform(-1, 1)) for k in
             ["momentum", "trend", "reversion", "flow", "volatility"]}
        s = e.score(x, d, int(rng.integers(0, 3)))
        assert -100.0 <= s <= 100.0


def test_drift_detects_shift():
    dm = DriftMonitor(delta=0.0001, threshold=2.0, warm=20)
    for _ in range(200):
        dm.update(1.0)
    fired = False
    for _ in range(300):
        if dm.update(0.0):
            fired = True
            break
    assert fired, "لم يُكتشف الانجراف"


def test_regime_classes():
    r = RegimeDetector(lookback=200)
    rng = np.random.default_rng(2)
    for _ in range(200):
        r.classify(float(abs(rng.standard_normal()) * 0.01), 0.0)
    assert r.classify(0.9, 0.0) == 2
    assert r.classify(0.001, 0.9) == 1
