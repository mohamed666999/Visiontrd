#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""مثال: مقارنة الأنظمة A/B/C/D/E على رمز واحد بنفس التكاليف وقواعد التنفيذ."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config import Config
from data import load_market, make_synthetic_data
from baselines import capital_curves, SCHEMES, pretty
from backtest import run, metrics
import pandas as pd

cfg = Config()
SYMBOL, INTERVAL, BARS = "BTCUSDT", "15m", 8000

try:
    df = load_market(SYMBOL, INTERVAL, BARS, cfg.market_base, cfg.path(cfg.cache_dir))
except Exception as e:
    print(f"تعذّر الجلب ({e}) — بيانات صناعية.")
    df = make_synthetic_data(BARS)

warm = max(800, len(df) // 5)
curves = capital_curves(df, cfg, warmup=warm, seed=7)
table = pd.DataFrame({
    name: metrics(curves[name], cfg, len(run(df, cfg, mode=mode, warmup=warm)["trades"]))
    for name, mode in SCHEMES
}).T[["total_return", "sharpe", "sortino", "max_drawdown", "calmar", "n_trades"]]

print(f"\n=== {SYMBOL} {INTERVAL} ({len(df)} شمعة) ===\n")
print(pretty(table))
