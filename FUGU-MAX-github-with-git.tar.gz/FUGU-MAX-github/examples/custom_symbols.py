#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""مثال: تشغيل النظام عبر عدّة أزواج ومقارنة التعميم."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config import Config
from data import load_market, make_synthetic_data
from baselines import compare_symbols

cfg = Config()
SYMBOLS = ["BTCUSDT", "ETHUSDT", "SOLUSDT", "BNBUSDT", "XRPUSDT"]


def loader(sym):
    try:
        return load_market(sym, cfg.interval, 6000, cfg.market_base, cfg.path(cfg.cache_dir))
    except Exception:
        return make_synthetic_data(6000, seed=abs(hash(sym)) % 10_000)


res = compare_symbols(loader, SYMBOLS, cfg, warmup=1200)
print(res[["symbol", "mode", "total_return", "sharpe", "max_drawdown", "n_trades"]].to_string(index=False))
