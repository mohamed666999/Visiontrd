#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""مثال: قراءة إشارة بصيغة JSON واستخدامها برمجيًا."""
import json, subprocess, sys, os

root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
out = subprocess.run(
    [sys.executable, os.path.join(root, "fugu_indicator.py"),
     "--symbol", "BTCUSDT", "--interval", "15m", "--demo", "--json"],
    capture_output=True, text=True, cwd=root)

raw = out.stdout.strip()
raw = raw[raw.find("{"):]          # تجاهل أي سطور تحذير قبل JSON
data = json.loads(raw)

print(f"الرمز          : {data['symbol']} {data['timeframe']}")
print(f"الدرجة          : {data['score']:+.1f}")
print(f"القرار          : {data['action']}")
print(f"النظام          : {data['regime_name']}  |  الإجماع: {data['agreement']:.0%}")
print(f"بوابة الميتا    : {data['meta_probability']:.2f}")
print("\nأعلى الخبراء وزنًا:")
for k, v in sorted(data["expert_weights"].items(), key=lambda x: -x[1])[:4]:
    print(f"  {k:11s} وزن {v:.2%}  إشارة {data['expert_signals'].get(k, 0):+.2f}")
