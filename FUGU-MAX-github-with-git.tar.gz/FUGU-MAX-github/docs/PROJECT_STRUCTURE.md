# هيكل المشروع

```
FUGU-MAX/
│
├── config.py                  الإعدادات + قراءة المفاتيح من .env (لا أسرار في الشيفرة)
├── data.py                    بيانات بينانس USDⓈ-M + مولّد بيانات صناعية
├── features.py                37 ميزة سببية + تجميعها إلى إشارات خبراء
├── labels.py                  التسميات الثلاث: signal / barrier / meta
├── models.py                  Adaptive Ensemble + Drift + Regime
├── strategy.py                ميتا + حجم + SL/TP + مدير مخاطر
├── backtest.py                محرّك Walk-Forward + المقاييس
├── baselines.py               الأنظمة المرجعية A/B/C/D/E
├── fugu_indicator.py          إشارة الآن، مفصّلة
├── train_and_report.py        تقرير بحثي + رسوم + حفظ الحالة
├── paper_engine.py            محرّك حيّ Paper/Demo
├── exchange.py                عميل بينانس USDⓈ-M موقّع
├── observer.py                مُسجِّل مستقل + Telegram
├── telegram_test.py           اختبار قناة المراقبة
│
├── tests/
│   ├── test_features.py       22 اختبارًا: منع التطلّع، الحدود
│   ├── test_labels.py         صحة التسميات وسياسة SL-أولًا
│   ├── test_models.py         تعلّم RLS/Logistic، الأوزان، الانجراف، الأنظمة
│   └── test_backtest.py       التنفيذ عند الفتح، التجميد، المحاسبة
│
├── examples/
│   ├── compare_baselines.py   مقارنة الأنظمة برمجيًا
│   ├── custom_symbols.py      عدّة أزواج ومقارنة التعميم
│   └── indicator_json.py      قراءة الإشارة بصيغة JSON
│
├── scripts/
│   ├── check.sh               تجميع + اختبارات
│   ├── run_indicator.sh       إشارة سريعة
│   ├── run_report.sh          تقرير بحثي
│   ├── run_paper.sh           تشغيل ورقى (لا أوامر)
│   └── run_demo.sh            تشغيل على حساب الديمو
│
├── docs/
│   ├── ARCHITECTURE.md        المعمارية وتفصيل المكوّنات
│   ├── RESEARCH.md            المنهج البحثي والأخطاء المكتشفة
│   ├── USAGE.md               دليل الاستخدام التفصيلي
│   ├── FAQ.md                 أسئلة متكرّرة
│   ├── ROADMAP.md             خارطة الطريق
│   ├── PROJECT_STRUCTURE.md   هذا الملف
│   └── DISCLAIMER.md          إخلاء المسؤولية
│
├── .github/
│   ├── workflows/
│   │   ├── tests.yml          اختبارات على 3 إصدارات بايثون
│   │   └── backtest.yml       تقرير صناعي عند الطلب
│   ├── ISSUE_TEMPLATE/
│   │   ├── bug_report.md
│   │   ├── feature_request.md
│   │   └── config.yml
│   └── PULL_REQUEST_TEMPLATE.md
│
├── data_cache/.gitkeep        كاش البيانات (مستثنى المحتوى)
├── reports/.gitkeep           مخرجات التشغيل (مستثنى المحتوى)
│
├── .env.example               قالب المفاتيح (يُرفع)
├── .env                       مفاتيحك الفعلية (مستثنى — لا يُرفع أبدًا)
├── .gitignore
├── .gitattributes
├── .editorconfig
├── Makefile                   أوامر مختصرة
├── requirements.txt
├── requirements-dev.txt
├── pyproject.toml
├── setup.cfg                  إعداد flake8
├── README.md
├── CHANGELOG.md
├── CONTRIBUTING.md
├── CODE_OF_CONDUCT.md
├── SECURITY.md
├── NOTICE
└── LICENSE
```

## الملفات التي لا تُرفع

- `.env` — يحتوي المفاتيح الفعلية. مستثنى في `.gitignore`.
- `data_cache/*` — كاش بيانات يُعاد توليده.
- `reports/*` — مخرجات تشغيل وقاعدة بيانات الرصد.
- `__pycache__/` و`.pytest_cache/`.
