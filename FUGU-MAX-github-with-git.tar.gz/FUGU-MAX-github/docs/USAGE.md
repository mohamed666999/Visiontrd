# دليل الاستخدام التفصيلي

## 0) المتطلبات

- Python 3.10 أو أحدث.
- اتصال إنترنت لجلب بيانات بينانس (اختياري: كل الأوامر تعمل بـ`--demo` بلا إنترنت).

```bash
pip install -r requirements.txt
```

---

## 1) اختبارات المشروع

```bash
bash scripts/check.sh          # تجميع + اختبارات
python -m pytest tests -q      # الاختبارات فقط
python -m pytest tests/test_backtest.py -v
```

يجب أن تنجح 22 اختبارًا. أهمّها اختبارات منع التطلّع للمستقبل.

---

## 2) إشارة سريعة

```bash
python fugu_indicator.py --symbol BTCUSDT --interval 15m
python fugu_indicator.py --symbol ETHUSDT --interval 1h
python fugu_indicator.py --symbol SOLUSDT --json        # مخرَج JSON للبرمجة
python fugu_indicator.py --demo --bars 4000             # بيانات صناعية
```

الخيارات:

| الخيار | المعنى | الافتراضي |
|---|---|---|
| `--symbol` | رمز العقد | `BTCUSDT` |
| `--interval` | الفريم | `15m` |
| `--bars` | عدد الشمعات | `8000` |
| `--demo` | بيانات صناعية بلا إنترنت | مغلق |
| `--json` | مخرَج JSON | مغلق |

---

## 3) تقرير بحثي كامل

```bash
python train_and_report.py --symbol BTCUSDT --interval 15m --bars 8000
python train_and_report.py --symbols BTCUSDT,ETHUSDT,SOLUSDT --bars 8000
python train_and_report.py --demo --bars 6000
```

يُنتج في مجلد `reports/`:

- `report.json` — جدول مقارنة الأنظمة ونتائج Walk-Forward.
- `fugu_max_<SYMBOL>.png` — منحنيات رأس المال ودرجة المؤشر.
- `model_state_<SYMBOL>.npz` — أوزان النموذج بعد التدريب.

---

## 4) التشغيل الحيّ

### ورقى بالكامل (لا يُرسل أي أمر)

```bash
bash scripts/run_paper.sh
# أو
python paper_engine.py --symbols BTCUSDT,ETHUSDT,SOLUSDT --interval 15m
```

### حساب بينانس الديمو (أموال وهمية)

```bash
cp .env.example .env    # املأ BINANCE_DEMO_KEY و BINANCE_DEMO_SECRET
bash scripts/run_demo.sh
# أو
python paper_engine.py --symbols BTCUSDT,ETHUSDT --interval 15m --demo-account
```

### تشغيل مرة واحدة (لا حلقة دائمة)

```bash
python paper_engine.py --symbols BTCUSDT --once
```

الخيارات:

| الخيار | المعنى |
|---|---|
| `--symbols` | قائمة رموز مفصولة بفواصل |
| `--interval` | الفريم |
| `--bars` | عدد الشمعات لكل دورة |
| `--poll` | ثواني بين الدورات (افتراضي 20) |
| `--demo-data` | بيانات صناعية بلا إنترنت |
| `--demo-account` | إرسال أوامر فعلية على حساب الديمو |
| `--once` | دورة واحدة ثم خروج |

---

## 5) Telegram

```bash
python telegram_test.py
```

يُرسل رسالة تعريفية ورسالة نموذجية. إن لم تصلك:

1. راجع `TELEGRAM_TOKEN` و`TELEGRAM_CHAT_ID` في `.env`.
2. تأكد أنك بدأت محادثة مع البوت وأرسلت له `/start` (البوت لا يستطيع البدء معك).
3. لمعرفة `chat_id`: أرسل رسالة للبوت ثم افتح
   `https://api.telegram.org/bot<TOKEN>/getUpdates` واقرأ `message.chat.id`.

---

## 6) قراءة قاعدة بيانات الرصد

كل حدث يُخزَّن في `reports/fugu_observer.db` (SQLite):

```bash
sqlite3 reports/fugu_observer.db \
  "SELECT timestamp, symbol, event_type, payload_json FROM events ORDER BY id DESC LIMIT 20;"
```

```python
from observer import Observer
o = Observer("reports/fugu_observer.db")
for e in o.recent(10):
    print(e["event_type"], e.get("symbol"), e.get("score"), e.get("action"))
```

أنواع الأحداث: `SIGNAL` · `OPEN` · `CLOSE` · `HEARTBEAT` · `ERROR`.
